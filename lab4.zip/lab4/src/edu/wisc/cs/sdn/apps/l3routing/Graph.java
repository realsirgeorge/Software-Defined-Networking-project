package edu.wisc.cs.sdn.apps.l3routing;

import java.util.ArrayList;
import java.util.HashMap;

import net.floodlightcontroller.core.IOFSwitch;

public class Graph {
	public Graph()	{
		
	}
	
	public HashMap<ArrayList<IOFSwitch>, ArrayList<IOFSwitch>> computeShortestPaths(){
		return null;
	}
}
